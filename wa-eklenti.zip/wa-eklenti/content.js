/* content.js — web.whatsapp.com (Normal & Business) üzerinde otomatik gönderim ve hata tespiti */
'use strict';

(function () {
  const ext = typeof browser !== 'undefined' ? browser : chrome;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function isLoginScreen() {
    return !!(
      document.querySelector('canvas[aria-label*="QR"], canvas[aria-label*="Scan"], div[data-ref]') ||
      /WhatsApp.{0,20}(giriş|QR|bağla|Link with phone)/i.test(document.body ? document.body.innerText.slice(0, 800) : '')
    );
  }

  function isInvalidNumberModal() {
    const dialogs = document.querySelectorAll('div[role="dialog"], div[data-animate-modal-popup="true"]');
    for (const d of dialogs) {
      const txt = (d.innerText || '').toLowerCase();
      if (
        txt.includes('geçersiz') ||
        txt.includes('invalid') ||
        txt.includes('whatsapp') && (txt.includes('bulunamadı') || txt.includes('not on'))
      ) {
        const okBtn = d.querySelector('button');
        if (okBtn) okBtn.click();
        return true;
      }
    }
    return false;
  }

  function findSendButton() {
    const selectors = [
      'button[aria-label="Send"]',
      'button[aria-label="Gönder"]',
      'button[data-tab="11"]',
      'span[data-icon="send"]',
      'span[data-icon="wds-ic-send-filled"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el.closest('button') || el;
    }
    return null;
  }

  function findComposer() {
    return (
      document.querySelector('footer div[contenteditable="true"][role="textbox"]') ||
      document.querySelector('div[contenteditable="true"][data-tab="10"]')
    );
  }

  async function trySend(timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 25000);
    while (Date.now() < deadline) {
      if (isLoginScreen()) {
        return { status: 'err', code: 'WA_LOGIN', error: 'WhatsApp Web oturumu kapalı. QR kodu okutun.' };
      }
      if (isInvalidNumberModal()) {
        return { status: 'err', code: 'WA_NOT_ON_WA', error: 'Numara WhatsApp’ta kayıtlı değil veya geçersiz.' };
      }
      const btn = findSendButton();
      const box = findComposer();
      if (btn) {
        await sleep(450);
        btn.click();
        await sleep(900);
        return { status: 'ok' };
      }
      if (box && (box.innerText || '').trim().length > 0) {
        await sleep(450);
        box.focus();
        box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        await sleep(900);
        return { status: 'ok' };
      }
      await sleep(500);
    }
    return {
      status: 'err',
      code: findComposer() ? 'WA_SEND_BTN' : 'WA_TIMEOUT',
      error: findComposer()
        ? 'Gönder düğmesi bulunamadı (WhatsApp Web arayüzü geç yüklendi).'
        : 'Sohbet ekranı zaman aşımına uğradı (internet veya WhatsApp Web yavaş).'
    };
  }

  ext.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== 'DO_SEND') return;
    trySend(msg.timeoutMs || 25000).then(sendResponse);
    return true;
  });
})();
