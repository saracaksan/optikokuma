/* bridge.js — Sıraç Aksan Optik Okuma PWA ile eklenti arka plan köprüsü */
'use strict';

(function () {
  const ext = typeof browser !== 'undefined' ? browser : chrome;

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    if (ev.data.type === 'OPTIK_WA_START' && ev.data.payload && ev.data.payload.app === 'sirac-aksan-optik-okuma') {
      try {
        ext.runtime.sendMessage({ type: 'START_QUEUE', payload: ev.data.payload });
      } catch (e) { }
    }
  });

  ext.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'OPTIK_WA_RESULT') {
      window.postMessage({ type: 'OPTIK_WA_RESULT', result: msg.result }, '*');
    }
  });
})();
