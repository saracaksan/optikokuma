/* background.js — Chrome / Edge / Brave / Firefox arka plan WhatsApp gönderim motoru */
'use strict';

const ext = typeof browser !== 'undefined' ? browser : chrome;

let state = {
  running: false,
  paused: false,
  waType: 'web',
  delaySec: 10,
  items: [],
  index: 0,
  results: [],
  sourceTabId: null,
  waTabId: null
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function saveState() {
  try { ext.storage.local.set({ waQueueState: state }); } catch (e) { }
}

function notifySource(result) {
  if (!state.sourceTabId) return;
  try {
    ext.tabs.sendMessage(state.sourceTabId, { type: 'OPTIK_WA_RESULT', result });
  } catch (e) { }
}

function waitTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (ok) => {
      if (done) return;
      done = true;
      ext.tabs.onUpdated.removeListener(onUpd);
      clearTimeout(t);
      resolve(ok);
    };
    const onUpd = (id, info) => {
      if (id === tabId && info.status === 'complete') finish(true);
    };
    const t = setTimeout(() => finish(false), timeoutMs || 25000);
    ext.tabs.onUpdated.addListener(onUpd);
  });
}

async function ensureWaTab() {
  if (state.waTabId) {
    try {
      const existing = await ext.tabs.get(state.waTabId);
      if (existing && existing.id) return existing.id;
    } catch (e) {
      state.waTabId = null;
    }
  }
  const tabs = await ext.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (tabs && tabs.length) {
    state.waTabId = tabs[0].id;
    return state.waTabId;
  }
  // Arka planda (active: false) yeni sekme açar; kullanıcı mevcut işine devam eder
  const created = await ext.tabs.create({ url: 'https://web.whatsapp.com/', active: false });
  state.waTabId = created.id;
  await waitTabComplete(state.waTabId, 25000);
  return state.waTabId;
}

async function processLoop() {
  if (!state.running) return;
  saveState();

  while (state.running && state.index < state.items.length) {
    if (state.paused) {
      await sleep(500);
      continue;
    }
    const item = state.items[state.index];
    const phone = String(item.phone || '').replace(/\D/g, '');
    let res;

    if (!/^\d{10,15}$/.test(phone)) {
      res = { key: item.key, name: item.name, phone, status: 'err', code: 'WA_INVALID_PHONE', error: 'Telefon numarası biçimi geçersiz.' };
    } else {
      try {
        const tabId = await ensureWaTab();
        const url = `https://web.whatsapp.com/send?phone=${encodeURIComponent(phone)}&text=${encodeURIComponent(item.text || '')}`;
        await ext.tabs.update(tabId, { url, active: false });
        await waitTabComplete(tabId, 25000);
        await sleep(1800);

        let reply = null;
        try {
          reply = await ext.tabs.sendMessage(tabId, { type: 'DO_SEND', timeoutMs: 25000 });
        } catch (err) {
          reply = { status: 'err', code: 'WA_TAB_CLOSED', error: 'WhatsApp Web sekmesine ulaşılamadı (sekme kapatılmış olabilir).' };
        }
        res = Object.assign({ key: item.key, name: item.name, phone }, reply || { status: 'err', code: 'WA_TIMEOUT', error: 'Yanıt alınamadı.' });
      } catch (e) {
        res = { key: item.key, name: item.name, phone, status: 'err', code: 'WA_TAB_CLOSED', error: String(e && e.message || e) };
      }
    }

    state.results.push(res);
    state.index++;
    saveState();
    notifySource(res);

    // Oturum kapalıysa kuyruğu duraklat ki tüm numaralar boşa hata almasın
    if (res.code === 'WA_LOGIN') {
      state.paused = true;
      saveState();
      continue;
    }

    if (state.running && state.index < state.items.length) {
      const waitMs = (Math.max(5, Number(state.delaySec) || 10) + Math.random() * 2) * 1000;
      const stepEnd = Date.now() + waitMs;
      while (state.running && !state.paused && Date.now() < stepEnd) {
        await sleep(300);
      }
    }
  }

  if (state.index >= state.items.length) {
    state.running = false;
    state.paused = false;
    saveState();
  }
}

ext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'START_QUEUE') {
    const p = msg.payload || {};
    state = {
      running: true,
      paused: false,
      waType: p.waType || 'web',
      delaySec: Math.max(5, Number(p.delaySec) || 10),
      items: Array.isArray(p.items) ? p.items : [],
      index: 0,
      results: [],
      sourceTabId: sender && sender.tab ? sender.tab.id : state.sourceTabId,
      waTabId: state.waTabId
    };
    saveState();
    processLoop();
    sendResponse({ ok: true, count: state.items.length });
    return true;
  }

  if (msg.type === 'GET_STATE') {
    sendResponse(state);
    return true;
  }

  if (msg.type === 'PAUSE_QUEUE') {
    state.paused = !state.paused;
    saveState();
    sendResponse(state);
    return true;
  }

  if (msg.type === 'STOP_QUEUE') {
    state.running = false;
    state.paused = false;
    saveState();
    sendResponse(state);
    return true;
  }
});
