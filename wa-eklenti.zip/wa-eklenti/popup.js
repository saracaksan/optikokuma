/* popup.js — Eklenti kontrol ve rapor paneli */
'use strict';

const ext = typeof browser !== 'undefined' ? browser : chrome;
const $ = (id) => document.getElementById(id);

let latestState = null;

function render(st) {
  if (!st) return;
  latestState = st;
  const total = (st.items || []).length;
  const done = st.index || 0;
  const okN = (st.results || []).filter((x) => x.status === 'ok').length;
  const errN = (st.results || []).filter((x) => x.status === 'err').length;

  $('status').textContent = st.running
    ? (st.paused ? 'Durum: Duraklatıldı (QR / kullanıcı bekliyor)' : 'Durum: Arka planda gönderiliyor…')
    : 'Durum: Hazır (Normal & Business Web)';
  $('s-prog').textContent = `${done} / ${total}`;
  $('s-ok').textContent = String(okN);
  $('s-err').textContent = String(errN);
  $('btn-pause').textContent = st.paused ? 'Devam Et' : 'Duraklat';

  const log = $('log');
  if (!st.results || !st.results.length) {
    log.textContent = 'Henüz gönderim kaydı yok.';
    return;
  }
  log.innerHTML = st.results.slice(-40).reverse().map((r) => {
    const cls = r.status === 'ok' ? 'ok' : 'err';
    const info = r.status === 'ok' ? 'Gönderildi ✓' : `[${r.code || 'ERR'}] ${r.error || 'Hata'}`;
    return `<div class="${cls}"><b>${r.name || r.phone}</b>: ${info}</div>`;
  }).join('');
}

async function refresh() {
  try {
    const st = await ext.runtime.sendMessage({ type: 'GET_STATE' });
    render(st);
  } catch (e) { }
}

$('btn-start').addEventListener('click', async () => {
  const txt = $('ta').value.trim();
  if (!txt) return;
  try {
    const payload = JSON.parse(txt);
    if (!Array.isArray(payload.items) || !payload.items.length) throw new Error('Kuyruk boş.');
    await ext.runtime.sendMessage({ type: 'START_QUEUE', payload });
    $('ta').value = '';
    refresh();
  } catch (e) {
    $('status').textContent = 'Hata: Geçersiz kuyruk JSON verisi.';
  }
});

$('btn-pause').addEventListener('click', async () => {
  const st = await ext.runtime.sendMessage({ type: 'PAUSE_QUEUE' });
  render(st);
});

$('btn-stop').addEventListener('click', async () => {
  const st = await ext.runtime.sendMessage({ type: 'STOP_QUEUE' });
  render(st);
});

$('btn-csv').addEventListener('click', () => {
  const rows = (latestState && latestState.results) || [];
  if (!rows.length) return;
  const esc = (v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const lines = [['Alıcı', 'Telefon', 'Durum', 'Hata Kodu', 'Açıklama'].map(esc).join(';')];
  rows.forEach((r) => lines.push([r.name, r.phone, r.status === 'ok' ? 'Gönderildi' : 'Hata', r.code || '', r.error || ''].map(esc).join(';')));
  const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'wa-eklenti-rapor.csv';
  a.click();
});

refresh();
setInterval(refresh, 1500);
